Patronus AI brand kit
https://www.patronus.ai/brand

LOGOS (logos/)
  lockup/lockup-horizontal-{ink,bone}            "Patronus AI", the primary lockup and the one the site uses
  lockup/lockup-stacked-{ink,bone}               "Patronus AI", for square and tall spaces
  lockup/lockup-horizontal-patronus-{ink,bone}   "Patronus", the short form
  lockup/lockup-stacked-patronus-{ink,bone}      "Patronus", the short form, stacked
  mark/cube-{ink,bone}                           the cube alone, one drawing at every size
  Each as SVG and PNG. Ink PNGs are transparent; bone PNGs sit on an ink tile. Every PNG includes its clear space.

BACKGROUNDS AND BANNERS (banners/)
  Link preview      1200 × 630   link-headline-bone.png, link-headline-ink.png, link-logo-bone.png, link-logo-ink.png
  X header          1500 × 500   x-header-line-bone.png, x-header-line-ink.png, x-header-logo-bone.png, x-header-logo-ink.png
  LinkedIn profile  1584 × 396   linkedin-profile-line-bone.png, linkedin-profile-line-ink.png, linkedin-profile-logo-bone.png, linkedin-profile-logo-ink.png
  LinkedIn Page     1128 × 191   linkedin-page-line-bone.png, linkedin-page-line-ink.png, linkedin-page-logo-bone.png, linkedin-page-logo-ink.png
  Calls and slides  1920 × 1080   wide-headline-bone.png, wide-headline-ink.png, wide-logo-bone.png, wide-logo-ink.png, wide-line-bone.png, wide-line-ink.png, wide-photo-fuji.png, wide-photo-alabama-hills.png
  Exported at 2x, except the photographs (1920 x 1080). Photo credits are at https://www.patronus.ai/imagery

RULES (usage-sheet.png shows them)
  Clear space: Keep one quarter of the cube’s height clear on every side.
  16 px       Cube alone, smallest. Use the favicon drawing.
  18 px +     The cube. One drawing at every size, also in every lockup.
  96 px wide  Horizontal lockup, smallest (78 px for “Patronus”).
  Color: ink #1D1D15 on bone #EEEEE6, or bone on ink. No other colors.
  Don't rotate, tilt, mirror, recolor or stretch it. No outlines, shadows or glows. Never place it on a photograph.

COLORS (colors/)
  patronus-colors.ase (Adobe swatches), .json and .txt.
  Core: ink and bone.
  Chart: Use in this order for three or more series. One series is ink; two are ink and gray.

TYPE (fonts/)
  Host Grotesk    Headlines, navigation and buttons. https://fonts.google.com/specimen/Host+Grotesk
  Source Serif 4  Reading text. https://fonts.google.com/specimen/Source+Serif+4
  Geist Mono      Labels, data and credits. https://fonts.google.com/specimen/Geist+Mono
  All three are licensed under the SIL Open Font License 1.1 (OFL.txt in each folder). Variable TTFs from google/fonts.

IMAGERY
  Papers   False color, from above
  Domains  True color, from the ground
  Posts    Warm black and white
  Team     Real photographs

PRESS
  contact@patronus.ai
